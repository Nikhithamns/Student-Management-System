package com.nishi.studentsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
